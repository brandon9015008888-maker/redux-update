@echo off
setlocal
pushd "%~dp0"
if errorlevel 1 goto incomplete
for %%F in ("Redux.exe" "Redux.dll" "Redux.deps.json" "Redux.runtimeconfig.json" "_Lib\DivinityModManagerCore.dll" "_Lib\ReactiveUI.dll" "_Lib\LSLibNative.dll" "Resources\AppFeatures.json" "Tools\Toolbox.exe") do (
  if not exist "%%~F" (
    echo The extracted Redux folder is missing %%~F.
    goto incomplete
  )
)
start "" "%~dp0Redux.exe"
popd
exit /b 0
:incomplete
echo.
echo Right-click the downloaded ZIP, choose Extract All, then open
echo Redux-Preview inside the extracted folder. Keep _Lib, Resources,
echo Tools and Updater beside Redux.exe.
echo.
pause
exit /b 1
